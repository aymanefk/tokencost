"""Command-line interface for tokencost."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import Price, estimate_cost, estimate_tokens, load_prices


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tokencost",
        description="Estimate token count and cost of a text (heuristic, no dependencies).",
    )
    p.add_argument("file", nargs="?", help="Text file to analyse (default: read stdin).")
    p.add_argument("--prices", help="JSON price table (USD per 1M tokens).")
    p.add_argument("--model", help="Model name to look up in the price table.")
    p.add_argument(
        "--input-price", type=float, help="USD per 1M input tokens (overrides table)."
    )
    p.add_argument(
        "--output-price", type=float, help="USD per 1M output tokens (overrides table)."
    )
    p.add_argument(
        "--expected-output",
        type=int,
        default=0,
        help="Expected number of output tokens (default: 0).",
    )
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    text = Path(args.file).read_text(encoding="utf-8") if args.file else sys.stdin.read()
    tokens = estimate_tokens(text)
    print(f"Estimated input tokens: {tokens}")

    price: Price | None = None
    if args.prices and args.model:
        table = load_prices(args.prices)
        if args.model not in table:
            print(f"Model {args.model!r} not found in {args.prices}.", file=sys.stderr)
            return 2
        price = table[args.model]
    if args.input_price is not None and args.output_price is not None:
        price = Price(args.input_price, args.output_price)

    if price is not None:
        cost = estimate_cost(tokens, args.expected_output, price)
        print(f"Estimated cost: ${cost:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
