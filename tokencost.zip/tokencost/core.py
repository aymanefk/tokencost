"""Core logic: estimate the number of tokens in a text and the cost of a prompt.

The estimate is a heuristic (no tokenizer dependency): roughly 4 characters or
0.75 words per token for English-like text. It is meant for quick budgeting,
not for exact billing.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

CHARS_PER_TOKEN = 4.0

_WORD_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)


@dataclass(frozen=True)
class Price:
    """Price in USD per 1 million tokens."""

    input: float
    output: float


def estimate_tokens(text: str) -> int:
    """Return a rough token estimate for ``text``.

    Averages a character-based and a word-based estimate, which is more stable
    than either alone across prose, code and non-English text.
    """
    if not text:
        return 0
    by_chars = len(text) / CHARS_PER_TOKEN
    # Words and punctuation marks are each roughly one token; blend with the
    # character-based estimate.
    by_words = len(_WORD_RE.findall(text))
    return max(1, round((by_chars + by_words) / 2))


def load_prices(path: str | Path) -> dict[str, Price]:
    """Load a price table from a JSON file.

    Expected format::

        {"my-model": {"input": 1.0, "output": 4.0}}

    Values are USD per 1M tokens.
    """
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    prices: dict[str, Price] = {}
    for name, entry in data.items():
        try:
            prices[name] = Price(float(entry["input"]), float(entry["output"]))
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Invalid price entry for {name!r}: {entry!r}") from exc
    return prices


def estimate_cost(
    input_tokens: int, output_tokens: int, price: Price
) -> float:
    """Return the cost in USD for the given token counts."""
    if input_tokens < 0 or output_tokens < 0:
        raise ValueError("Token counts must be non-negative.")
    return (input_tokens * price.input + output_tokens * price.output) / 1_000_000
