import json

import pytest

from tokencost import Price, estimate_cost, estimate_tokens, load_prices
from tokencost.cli import main


def test_empty_text_is_zero_tokens():
    assert estimate_tokens("") == 0


def test_nonempty_text_has_at_least_one_token():
    assert estimate_tokens("a") >= 1


def test_longer_text_has_more_tokens():
    assert estimate_tokens("hello world " * 100) > estimate_tokens("hello world")


def test_estimate_is_in_a_reasonable_range():
    text = "The quick brown fox jumps over the lazy dog. " * 50
    n = estimate_tokens(text)
    # ~4 chars per token => about len/4, allow a generous band.
    assert len(text) / 8 < n < len(text) / 2


def test_cost_computation():
    price = Price(input=2.0, output=8.0)
    assert estimate_cost(1_000_000, 500_000, price) == pytest.approx(6.0)


def test_negative_tokens_rejected():
    with pytest.raises(ValueError):
        estimate_cost(-1, 0, Price(1, 1))


def test_load_prices(tmp_path):
    f = tmp_path / "prices.json"
    f.write_text(json.dumps({"m": {"input": 1, "output": 2}}))
    assert load_prices(f) == {"m": Price(1.0, 2.0)}


def test_load_prices_invalid(tmp_path):
    f = tmp_path / "prices.json"
    f.write_text(json.dumps({"m": {"input": 1}}))
    with pytest.raises(ValueError):
        load_prices(f)


def test_cli_prints_cost(tmp_path, capsys):
    f = tmp_path / "prompt.txt"
    f.write_text("hello world " * 100)
    code = main(
        [str(f), "--input-price", "1", "--output-price", "2", "--expected-output", "100"]
    )
    out = capsys.readouterr().out
    assert code == 0
    assert "Estimated input tokens" in out
    assert "Estimated cost" in out


def test_cli_unknown_model(tmp_path, capsys):
    prices = tmp_path / "p.json"
    prices.write_text(json.dumps({"m": {"input": 1, "output": 2}}))
    f = tmp_path / "t.txt"
    f.write_text("hi")
    assert main([str(f), "--prices", str(prices), "--model", "nope"]) == 2
