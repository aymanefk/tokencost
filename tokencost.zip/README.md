# tokencost

Quick, dependency-free **token and cost estimation** for LLM prompts, as a Python library and a command-line tool.

> The token count is a heuristic (about 4 characters per token for English-like text). It is meant for fast budgeting, not exact billing. Always check your provider's usage dashboard for real figures.

## Features

- Estimate the number of tokens in any text file or stdin
- Compute the cost from a price table you control (USD per 1M tokens)
- Pure standard library, Python 3.9+
- Small, tested, MIT-licensed

## Installation

```bash
git clone https://github.com/aymanefk/tokencost.git
cd tokencost
pip install .
```

## Usage

### Command line

```bash
# Token estimate only
tokencost prompt.txt

# With cost, using explicit prices (USD per 1M tokens)
tokencost prompt.txt --input-price 0.5 --output-price 1.5 --expected-output 500

# With cost, using a price table
tokencost prompt.txt --prices prices.example.json --model example-small-model --expected-output 500

# From stdin
cat prompt.txt | tokencost
```

### Python

```python
from tokencost import Price, estimate_cost, estimate_tokens

text = open("prompt.txt", encoding="utf-8").read()
n = estimate_tokens(text)
cost = estimate_cost(n, 500, Price(input=0.5, output=1.5))
print(n, f"${cost:.6f}")
```

## Price table format

`prices.example.json` shows the format. The values in it are placeholders: replace them with your provider's current prices.

```json
{ "my-model": { "input": 1.0, "output": 4.0 } }
```

## Tests

```bash
pip install pytest
pytest
```

## Contributing

Issues and pull requests are welcome. Please add a test for any behaviour change.

## License

[MIT](LICENSE) - Copyright (c) 2026 Aymane Fkir
